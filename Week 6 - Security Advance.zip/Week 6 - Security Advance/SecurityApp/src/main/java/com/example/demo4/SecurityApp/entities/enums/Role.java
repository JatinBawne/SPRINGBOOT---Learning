package com.example.demo4.SecurityApp.entities.enums;

public enum Role {

    USER,
    CREATOR,
    ADMIN
}
