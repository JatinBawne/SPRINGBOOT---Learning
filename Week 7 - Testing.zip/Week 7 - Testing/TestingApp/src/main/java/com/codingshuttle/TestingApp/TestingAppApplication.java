package com.codingshuttle.TestingApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestingAppApplication.class, args);
	}

}
