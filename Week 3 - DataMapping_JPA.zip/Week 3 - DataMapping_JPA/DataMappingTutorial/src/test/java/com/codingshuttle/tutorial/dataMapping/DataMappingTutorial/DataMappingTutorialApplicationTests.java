package com.codingshuttle.tutorial.dataMapping.DataMappingTutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataMappingTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
