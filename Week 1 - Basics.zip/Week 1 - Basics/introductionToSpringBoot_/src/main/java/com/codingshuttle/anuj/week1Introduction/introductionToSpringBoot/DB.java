package com.codingshuttle.anuj.week1Introduction.introductionToSpringBoot;

public interface DB {

    String getData();
}
