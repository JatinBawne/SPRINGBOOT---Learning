package com.codingshuttle.anuj.week1Introduction.introductionToSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntroductionToSpringBootApplicationTests {

	@Test
	void contextLoads() {
		System.out.println("Anuj is running test");
	}

}
