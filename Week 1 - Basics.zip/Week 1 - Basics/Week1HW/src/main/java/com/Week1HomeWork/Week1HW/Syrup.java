package com.Week1HomeWork.Week1HW;

public interface Syrup {
    String getSyrupType();
}
