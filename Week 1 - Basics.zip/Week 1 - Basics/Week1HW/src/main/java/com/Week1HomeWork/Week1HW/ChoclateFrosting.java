package com.Week1HomeWork.Week1HW;


import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "frosting", havingValue = "choclate")
public class ChoclateFrosting implements Frosting {
    public String getFrostingType(){
        return "Choclate Frosting";
    }
}
