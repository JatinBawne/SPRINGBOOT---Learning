package com.Week1HomeWork.Week1HW;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "syrup", havingValue = "choclate")
public class ChoclateSyrup implements Syrup {
    public String getSyrupType(){
        return "Choclate Syrup";
    }
}
