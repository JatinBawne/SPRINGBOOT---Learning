package com.Week1HomeWork.Week1HW;

public interface Frosting {
    String getFrostingType();
}
