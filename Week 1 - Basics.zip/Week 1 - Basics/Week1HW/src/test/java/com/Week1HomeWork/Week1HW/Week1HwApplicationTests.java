package com.Week1HomeWork.Week1HW;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week1HwApplicationTests {

	@Test
	void contextLoads() {
	}

}
