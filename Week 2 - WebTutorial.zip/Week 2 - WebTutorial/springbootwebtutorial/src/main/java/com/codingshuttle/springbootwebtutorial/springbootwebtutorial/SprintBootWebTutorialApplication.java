package com.codingshuttle.springbootwebtutorial.springbootwebtutorial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprintBootWebTutorialApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprintBootWebTutorialApplication.class, args);
	}

}
